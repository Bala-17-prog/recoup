import json
import random
from datetime import datetime, timedelta

def generate_universal_demo_data(num_records=50, seed=42):
    random.seed(seed)
    
    recovery_types = [
        "PAYMENT_FAILURE", 
        "CHECKOUT_DROPOFF", 
        "SUBSCRIPTION_FAILURE", 
        "B2B_RECEIVABLE", 
        "MANDATE_FAILURE", 
        "PROMISE_TO_PAY"
    ]
    
    customers = ["Acme Corp", "TechFlow Inc", "Rahul Sharma", "Priya Singh", "Global Industries", "Neo Ventures", "Amit Patel", "Sneha Gupta"]
    
    records = []
    
    for i in range(1, num_records + 1):
        r_type = random.choice(recovery_types)
        amount = round(random.uniform(500, 50000), 2)
        
        record = {
            "record_id": f"INV-{1000 + i}",
            "customer_id": f"CUST-{random.randint(100, 999)}",
            "customer_name": random.choice(customers),
            "recovery_type": r_type,
            "amount": amount,
            "currency": "INR",
            "retry_count": random.randint(0, 3)
        }
        
        # Root Cause Determinism Seeds
        if r_type == "PAYMENT_FAILURE":
            record["error_code"] = random.choice(["insufficient_funds", "card_declined", "bank_timeout", "network_error", "authentication_failed"])
        elif r_type == "CHECKOUT_DROPOFF":
            record["abandonment_stage"] = random.choice(["payment_step", "pricing_friction", "session_timeout", "checkout_error"])
        elif r_type == "SUBSCRIPTION_FAILURE":
            record["sub_error"] = random.choice(["recurring_payment_failed", "expired_card", "insufficient_funds", "mandate_failed"])
        elif r_type == "B2B_RECEIVABLE":
            record["b2b_status"] = random.choice(["invoice_overdue", "payment_delayed", "disputed_invoice"])
            record["language"] = "HINGLISH" if random.random() > 0.5 else "ENGLISH"
        elif r_type == "MANDATE_FAILURE":
            record["mandate_error"] = random.choice(["mandate_failed", "mandate_expired", "retry_required"])
        elif r_type == "PROMISE_TO_PAY":
            base_date = datetime.now()
            offset = random.randint(-5, 5)
            promise_date = base_date + timedelta(days=offset)
            record["promise_date"] = promise_date.strftime("%Y-%m-%d")
            
            if offset < 0:
                record["promise_status"] = "MISSED"
            elif offset == 0:
                record["promise_status"] = "DUE TODAY"
            else:
                record["promise_status"] = "PENDING"

        # Compliance / Policy flags
        if random.random() < 0.1:
            record["compliance_flags"] = {"do_not_contact": True}
        elif random.random() < 0.15:
            record["compliance_flags"] = {"do_not_retry": True}
        else:
            record["compliance_flags"] = {}
            
        records.append(record)
        
    return records

if __name__ == "__main__":
    import os
    
    train_data = generate_universal_demo_data(50, seed=42)
    test_data = generate_universal_demo_data(30, seed=100)
    
    out_dir = r"D:\Projects\Recoup\data"
    os.makedirs(out_dir, exist_ok=True)
    
    with open(os.path.join(out_dir, "demo_data_train.json"), "w", encoding="utf-8") as f:
         json.dump(train_data, f, indent=2)
         
    with open(os.path.join(out_dir, "demo_data_test.json"), "w", encoding="utf-8") as f:
         json.dump(test_data, f, indent=2)
         
    print("Generated unified demo data.")
